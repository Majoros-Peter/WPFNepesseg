﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFNepesseg
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            dgTelepulesek.ItemsSource = Lista("");
        }

        private void cbMegyek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private List<Adatok> Lista(string path)
        {
            List<Adatok> lista = new();

            string[] sorok = File.ReadAllLines(path);
            foreach (string sor in sorok.Skip(1))
            {
                string[] adatok = sor.Split();
                lista.Add(new(adatok[2], adatok[3], adatok[4], int.Parse(adatok[5]), int.Parse(adatok[6])));
            }

            return lista;
        }
    }
}

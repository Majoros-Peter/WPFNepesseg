﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFNepesseg
{
    internal class Adatok
    {
        String _megye;
        String _telepulesNev;
        String _telepulesTipus; //község, nagyközség, város, ...
        int _ferfiLakosokSzama;
        int _noiLakosokSzama;

        public Adatok(string megye, string telepulesNev, string telepulesTipus, int ferfiLakosokSzama, int noiLakosokSzama)
        {
            _megye = megye;
            _telepulesNev = telepulesNev;
            _telepulesTipus = telepulesTipus;
            _ferfiLakosokSzama = ferfiLakosokSzama;
            _noiLakosokSzama = noiLakosokSzama;
        }

        public string Megye { get => _megye; }
        public string TelepulesNev { get => _telepulesNev; }
        public string TelepulesTipus { get => _telepulesTipus; }
        public int FerfiLakosokSzama { get => _ferfiLakosokSzama; }
        public int NoiLakosokSzama { get => _noiLakosokSzama; }
        public int LakosokSzamaEgyutt { get => _noiLakosokSzama + _ferfiLakosokSzama; }
    }
}
